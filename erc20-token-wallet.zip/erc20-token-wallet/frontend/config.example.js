// `npm run deploy:local` generates frontend/config.js automatically. Copy this file if you deploy manually.
window.APP_CONFIG = { tokenAddress: "0x0000000000000000000000000000000000000000", chainId: 31337 };
