const fs = require("fs");
const path = require("path");
const { ethers, network } = require("hardhat");

async function main() {
  const [deployer] = await ethers.getSigners();
  const supply = ethers.parseUnits("1000000", 18);

  const token = await (await ethers.getContractFactory("DecodeToken")).deploy(supply);
  await token.waitForDeployment();
  const address = await token.getAddress();
  const { chainId } = await ethers.provider.getNetwork();

  console.log(`DecodeToken deployed to ${address} on ${network.name} (chainId ${chainId})`);
  console.log(`Deployer ${deployer.address} holds 1,000,000 DLT`);

  // Hand the address to the frontend
  const cfg = `window.APP_CONFIG = ${JSON.stringify({ tokenAddress: address, chainId: Number(chainId) }, null, 2)};\n`;
  fs.writeFileSync(path.join(__dirname, "..", "frontend", "config.js"), cfg);
  console.log("frontend/config.js updated");
}

main().catch((e) => { console.error(e); process.exitCode = 1; });
