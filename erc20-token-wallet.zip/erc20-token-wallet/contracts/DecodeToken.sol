// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/**
 * @title DecodeToken
 * @notice Dependency-free ERC-20 implementation (EIP-20) with custom errors.
 * @dev Solidity >=0.8 reverts on arithmetic underflow/overflow, so no SafeMath is needed.
 *      Explicit balance checks are still performed to give callers a descriptive error.
 */
contract DecodeToken {
    string public constant name = "DecodeLabs Token";
    string public constant symbol = "DLT";
    uint8 public constant decimals = 18;
    uint256 public immutable totalSupply;

    mapping(address => uint256) private _balances;
    mapping(address => mapping(address => uint256)) private _allowances;

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    error InsufficientBalance(uint256 available, uint256 required);
    error InsufficientAllowance(uint256 available, uint256 required);
    error InvalidAddress(address account);

    /// @param initialSupply Total supply in base units (18 decimals), minted to the deployer.
    constructor(uint256 initialSupply) {
        totalSupply = initialSupply;
        _balances[msg.sender] = initialSupply;
        emit Transfer(address(0), msg.sender, initialSupply);
    }

    /// @notice Gasless read of an account's token balance.
    function balanceOf(address account) external view returns (uint256) {
        return _balances[account];
    }

    /// @notice Move `amount` tokens from the caller to `to`. Zero-value transfers are valid per EIP-20.
    function transfer(address to, uint256 amount) external returns (bool) {
        _transfer(msg.sender, to, amount);
        return true;
    }

    function approve(address spender, uint256 amount) external returns (bool) {
        if (spender == address(0)) revert InvalidAddress(spender);
        _allowances[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function allowance(address owner, address spender) external view returns (uint256) {
        return _allowances[owner][spender];
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 allowed = _allowances[from][msg.sender];
        if (allowed != type(uint256).max) {
            if (allowed < amount) revert InsufficientAllowance(allowed, amount);
            unchecked { _allowances[from][msg.sender] = allowed - amount; }
        }
        _transfer(from, to, amount);
        return true;
    }

    /// @dev Checks -> Effects -> Event. No external calls, so no reentrancy surface.
    function _transfer(address from, address to, uint256 amount) private {
        if (to == address(0)) revert InvalidAddress(to);
        uint256 fromBalance = _balances[from];
        if (fromBalance < amount) revert InsufficientBalance(fromBalance, amount);
        unchecked { _balances[from] = fromBalance - amount; } // safe: checked above
        _balances[to] += amount;
        emit Transfer(from, to, amount);
    }
}
