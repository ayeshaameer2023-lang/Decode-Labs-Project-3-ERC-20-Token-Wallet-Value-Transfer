const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture } = require("@nomicfoundation/hardhat-toolbox/network-helpers");

const SUPPLY = ethers.parseUnits("1000000", 18);
const ZERO = ethers.ZeroAddress;

async function deploy() {
  const [owner, alice, bob] = await ethers.getSigners();
  const token = await (await ethers.getContractFactory("DecodeToken")).deploy(SUPPLY);
  return { token, owner, alice, bob };
}

describe("DecodeToken (ERC-20)", () => {
  it("exposes metadata and mints the supply to the deployer", async () => {
    const { token, owner } = await loadFixture(deploy);
    expect(await token.name()).to.equal("DecodeLabs Token");
    expect(await token.symbol()).to.equal("DLT");
    expect(await token.decimals()).to.equal(18);
    expect(await token.totalSupply()).to.equal(SUPPLY);
    expect(await token.balanceOf(owner.address)).to.equal(SUPPLY);
  });

  describe("transfer", () => {
    it("moves tokens, conserves supply and emits Transfer", async () => {
      const { token, owner, alice } = await loadFixture(deploy);
      const amt = ethers.parseUnits("250.5", 18);
      await expect(token.transfer(alice.address, amt))
        .to.emit(token, "Transfer").withArgs(owner.address, alice.address, amt);
      expect(await token.balanceOf(alice.address)).to.equal(amt);
      expect(await token.balanceOf(owner.address)).to.equal(SUPPLY - amt);
    });

    it("allows sending the entire balance", async () => {
      const { token, owner, alice } = await loadFixture(deploy);
      await token.transfer(alice.address, SUPPLY);
      expect(await token.balanceOf(owner.address)).to.equal(0n);
    });

    it("treats a zero-value transfer as valid and emits an event", async () => {
      const { token, owner, alice } = await loadFixture(deploy);
      await expect(token.transfer(alice.address, 0n))
        .to.emit(token, "Transfer").withArgs(owner.address, alice.address, 0n);
    });

    it("reverts on overdraft (1 wei more than balance)", async () => {
      const { token, alice } = await loadFixture(deploy);
      await expect(token.transfer(alice.address, SUPPLY + 1n))
        .to.be.revertedWithCustomError(token, "InsufficientBalance")
        .withArgs(SUPPLY, SUPPLY + 1n);
    });

    it("reverts when a wallet with no funds tries to send", async () => {
      const { token, alice, bob } = await loadFixture(deploy);
      await expect(token.connect(alice).transfer(bob.address, 1n))
        .to.be.revertedWithCustomError(token, "InsufficientBalance");
    });

    it("reverts when sending to the zero address", async () => {
      const { token } = await loadFixture(deploy);
      await expect(token.transfer(ZERO, 1n)).to.be.revertedWithCustomError(token, "InvalidAddress");
    });

    it("rejects negative and out-of-range amounts at the ABI layer", async () => {
      const { token, alice } = await loadFixture(deploy);
      await expect(token.transfer(alice.address, -1n)).to.be.rejected;
      await expect(token.transfer(alice.address, 2n ** 256n)).to.be.rejected;
    });
  });

  describe("allowances", () => {
    it("approve + transferFrom decrements the allowance", async () => {
      const { token, owner, alice, bob } = await loadFixture(deploy);
      await expect(token.approve(alice.address, 100n))
        .to.emit(token, "Approval").withArgs(owner.address, alice.address, 100n);
      await token.connect(alice).transferFrom(owner.address, bob.address, 60n);
      expect(await token.allowance(owner.address, alice.address)).to.equal(40n);
      expect(await token.balanceOf(bob.address)).to.equal(60n);
    });

    it("reverts when the allowance is exceeded", async () => {
      const { token, owner, alice, bob } = await loadFixture(deploy);
      await token.approve(alice.address, 10n);
      await expect(token.connect(alice).transferFrom(owner.address, bob.address, 11n))
        .to.be.revertedWithCustomError(token, "InsufficientAllowance").withArgs(10n, 11n);
    });

    it("does not decrement an infinite allowance", async () => {
      const { token, owner, alice, bob } = await loadFixture(deploy);
      await token.approve(alice.address, ethers.MaxUint256);
      await token.connect(alice).transferFrom(owner.address, bob.address, 5n);
      expect(await token.allowance(owner.address, alice.address)).to.equal(ethers.MaxUint256);
    });
  });
});
